该工程是Tars快速入门示例的代码


目录名称 |功能
-----------------|----------------
HelloServer      |   开发快速入门的示例
ProxyServer      |   中转代理服务示例，作为HelloServer的代理服务