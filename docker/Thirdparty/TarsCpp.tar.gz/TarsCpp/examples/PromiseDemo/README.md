该工程是Tars promise编程示例的代码


目录名称 |功能
-----------------|----------------
AServer   |   promise编程的示例程序，用promsie方式去并行和串行访问BServer和CServer
